from django.apps import AppConfig


class CoplateConfig(AppConfig):
    name = 'coplate'
